/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Gabi Caproni
 *
 * Created on 12 de junho de 2025, 17:35
 */

#include <cstdlib>         
#include <iostream>        
#include <vector>          
#include <numeric>         
#include <algorithm>       
#include "OrdenacaoPonteiros.h" 

using namespace std;

// Função para listar os elementos de um vetor (usando ponteiros)
void listagem(int* inicio, int tam) {
    cout << "[";
    for (int i = 0; i < tam; i++) {
        cout << *(inicio + i); // Acessa o elemento usando aritmética de ponteiros
        if (i < tam - 1) {
            cout << ", ";
        }
    }
    cout << "]\n";
}

int main(int argc, char** argv) {

    const int TAM = 10;
    
    // --- Teste com Bubble Sort ---
    cout << "\n--- Teste com Bubble Sort ---\n";
    // Usando std::vector
    vector<int> vAleat_bubble = {11, 19, 12, 18, 13, 17, 14, 16, 15, 20}; // Caso médio/aleatório
    vector<int> vCres_bubble(TAM); // Vetor para melhor caso (já ordenado)
    iota(vCres_bubble.begin(), vCres_bubble.end(), 11); // Preenche com 11, 12, ..., 20
    vector<int> vDecre_bubble(TAM); // Vetor para pior caso (ordem inversa)
    iota(vDecre_bubble.begin(), vDecre_bubble.end(), 11);
    reverse(vDecre_bubble.begin(), vDecre_bubble.end()); // Inverte para decrescente

    cout << "Estado do vetor aleatório antes da ordenação:\n";
    listagem(vAleat_bubble.data(), TAM); // .data() retorna um ponteiro para o primeiro elemento
    bubbleSortPonteiros(vAleat_bubble.data(), vAleat_bubble.data() + TAM); // Passa o ponteiro inicial e o ponteiro final
    cout << "Estado do vetor aleatório depois da ordenação (Bubble Sort):\n";
    listagem(vAleat_bubble.data(), TAM);

    cout << "\nEstado do vetor crescente antes da ordenação:\n";
    listagem(vCres_bubble.data(), TAM);
    bubbleSortPonteiros(vCres_bubble.data(), vCres_bubble.data() + TAM);
    cout << "Estado do vetor crescente depois da ordenação (Bubble Sort):\n";
    listagem(vCres_bubble.data(), TAM);
             
    cout << "\nEstado do vetor decrescente antes da ordenação:\n";
    listagem(vDecre_bubble.data(), TAM);
    bubbleSortPonteiros(vDecre_bubble.data(), vDecre_bubble.data() + TAM);
    cout << "Estado do vetor decrescente depois da ordenação (Bubble Sort):\n";
    listagem(vDecre_bubble.data(), TAM);

    // --- Teste com Selection Sort ---
    cout << "\n--- Teste com Selection Sort ---\n";
    // Usando std::vector
    vector<int> vAleat_selection = {11, 19, 12, 18, 13, 17, 14, 16, 15, 20}; 
    vector<int> vCres_selection(TAM); 
    iota(vCres_selection.begin(), vCres_selection.end(), 11);
    vector<int> vDecre_selection(TAM);
    iota(vDecre_selection.begin(), vDecre_selection.end(), 11);
    reverse(vDecre_selection.begin(), vDecre_selection.end());

    cout << "Estado do vetor aleatório antes da ordenação:\n";
    listagem(vAleat_selection.data(), TAM);
    selectionSortPonteiros(vAleat_selection.data(), vAleat_selection.data() + TAM);
    cout << "Estado do vetor aleatório depois da ordenação (Selection Sort):\n";
    listagem(vAleat_selection.data(), TAM);

    cout << "\nEstado do vetor crescente antes da ordenação:\n";
    listagem(vCres_selection.data(), TAM);
    selectionSortPonteiros(vCres_selection.data(), vCres_selection.data() + TAM);
    cout << "Estado do vetor crescente depois da ordenação (Selection Sort):\n";
    listagem(vCres_selection.data(), TAM);

    cout << "\nEstado do vetor decrescente antes da ordenação:\n";
    listagem(vDecre_selection.data(), TAM);
    selectionSortPonteiros(vDecre_selection.data(), vDecre_selection.data() + TAM);
    cout << "Estado do vetor decrescente depois da ordenação (Selection Sort):\n";
    listagem(vDecre_selection.data(), TAM);

    // --- Teste com Insertion Sort ---
    cout << "\n--- Teste com Insertion Sort ---\n";
    // Usando std::vector
    vector<int> vAleat_insertion = {11, 19, 12, 18, 13, 17, 14, 16, 15, 20}; 
    vector<int> vCres_insertion(TAM); 
    iota(vCres_insertion.begin(), vCres_insertion.end(), 11);
    vector<int> vDecre_insertion(TAM);
    iota(vDecre_insertion.begin(), vDecre_insertion.end(), 11);
    reverse(vDecre_insertion.begin(), vDecre_insertion.end());

    cout << "Estado do vetor aleatório antes da ordenação:\n";
    listagem(vAleat_insertion.data(), TAM);
    insertionSortPonteiros(vAleat_insertion.data(), vAleat_insertion.data() + TAM);
    cout << "Estado do vetor aleatório depois da ordenação (Insertion Sort):\n";
    listagem(vAleat_insertion.data(), TAM);

    cout << "\nEstado do vetor crescente antes da ordenação:\n";
    listagem(vCres_insertion.data(), TAM);
    insertionSortPonteiros(vCres_insertion.data(), vCres_insertion.data() + TAM);
    cout << "Estado do vetor crescente depois da ordenação (Insertion Sort):\n";
    listagem(vCres_insertion.data(), TAM);

    cout << "\nEstado do vetor decrescente antes da ordenação:\n";
    listagem(vDecre_insertion.data(), TAM);
    insertionSortPonteiros(vDecre_insertion.data(), vDecre_insertion.data() + TAM);
    cout << "Estado do vetor decrescente depois da ordenação (Insertion Sort):\n";
    listagem(vDecre_insertion.data(), TAM);

    cout << "\nExemplo final do vetor ordenado (usando o último 'vAleat_insertion'):\n";
    for (int i = 0; i < TAM; i++) {
        cout << "O " << i + 1 << " º elemento do vetor ordenado é: " << vAleat_insertion[i] << endl;
    }

    return 0;
}