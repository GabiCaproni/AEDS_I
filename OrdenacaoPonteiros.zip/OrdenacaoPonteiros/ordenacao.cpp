/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.cc to edit this template
 */

#include "OrdenacaoPonteiros.h" // Inclui o cabeçalho da biblioteca

// Troca de dois elementos usando ponteiros
void trocar(int* a, int* b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

// Bubble Sort usando ponteiros
// 'inicio' aponta para o primeiro elemento do array
// 'fim' aponta para a posição após o último elemento do array (similar ao iterador end() de STL)
void bubbleSortPonteiros(int* inicio, int* fim) {
    if (inicio == fim) { // Array vazio ou com um único elemento
        return;
    }

    int* i = inicio;
    while (i != fim) {
        int* j = inicio;
        // O loop interno vai até (fim - 1 - (i - inicio)) para otimização,
        // mas sem usar aritmética de ponteiro que simule índice diretamente.
        // Basicamente, a cada passada, o maior elemento vai para o final do sub-array não ordenado.
        int* limite_interno = fim;
        int* k = inicio; // Contador para saber quantos elementos já estão ordenados no final
        while (k != i) { // Para cada elemento já processado por 'i', diminuímos o limite_interno
            limite_interno--;
            k++;
        }
        
        while (j != limite_interno && (j + 1) != fim) { // Evita acessar fora do limite e garante (j+1) é válido
            if (*j > *(j + 1)) {
                trocar(j, j + 1);
            }
            j++;
        }
        i++;
    }
}

// Selection Sort usando ponteiros
void selectionSortPonteiros(int* inicio, int* fim) {
    if (inicio == fim) { // Array vazio ou com um único elemento
        return;
    }

    int* i = inicio;
    while (i != fim) {
        int* minPtr = i; // Ponteiro para o menor elemento encontrado no sub-array não ordenado
        int* j = i + 1;  // Começa a busca pelo próximo elemento

        while (j != fim) {
            if (*j < *minPtr) {
                minPtr = j;
            }
            j++;
        }
        // Troca o elemento atual (apontado por i) com o menor elemento encontrado
        if (minPtr != i) {
            trocar(i, minPtr);
        }
        i++; // Move para a próxima posição para continuar a ordenação
    }
}

// Insertion Sort usando ponteiros
void insertionSortPonteiros(int* inicio, int* fim) {
    if (inicio == fim) { // Array vazio ou com um único elemento
        return;
    }

    int* i = inicio + 1; // Começa do segundo elemento
    while (i != fim) {
        int chave = *i; // Valor a ser inserido na posição correta
        int* j = i;     // Ponteiro para a posição atual da chave

        // Move os elementos maiores que a chave para a direita
        while (j != inicio && *(j - 1) > chave) {
            *j = *(j - 1); // Move o elemento para a direita
            j--;           // Move o ponteiro para a esquerda
        }
        *j = chave; // Insere a chave na posição correta
        i++;        // Move para o próximo elemento a ser inserido
    }
}