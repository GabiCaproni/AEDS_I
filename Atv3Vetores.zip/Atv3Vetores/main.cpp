/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Gabi Caproni
 *
 * Created on 20 de maio de 2025, 16:37
 */

#include <cstdlib>
#include <iostream>
#include <fstream>
#include <ctime>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    
/* Autor: Gabriella Caproni da Silva
 * Local: Unifal - Campus Santa Clara
 * Data: 20/05/2025
 * Disciplina: AEDs I - Prática
 * Objetivo: O objetivo deste código é manipular um vetor de 100 posições preenchido com números inteiros aleatórios, 
 * realizando diversas operações por meio de um menu de opções, como: contar a quantidade de ocorrências de um valor ou intervalo,
 *  buscar a primeira ocorrência de um valor, excluir a primeira ocorrência, inserir um valor em uma posição específica, remover 
 * todos os valores repetidos e exibir o vetor atual. 
 */

    const int TAM_MAX = 100;
    int vetor[TAM_MAX];
    int tamanho = 0;
    int opcao;

    //gera valores aleatorios que serão colocados no vetor
    srand(time(0));
    for (int i = 0; i < TAM_MAX; i++) {
        vetor[i] = rand() % 100; // valores de 0 a 99
    }
    tamanho = TAM_MAX; 


    //permite a vizualização do vetor inicial
    cout << "Os valores inseridos no vetor são: " << endl;
    for (int i = 0; i < TAM_MAX; i++) {
        cout << vetor[i] << " ";
    }
    

    //menu de opções para que o usuario decida qual manipulação quer no momento
    do {
        cout << "\nMenu de operações:\n";
        cout << "1. Contar quantas vezes um valor aparece\n";
        cout << "2. Contar quantos valores estão em um intervalo\n";
        cout << "3. Buscar a primeira ocorrência de um valor\n";
        cout << "4. Excluir a primeira ocorrência de um valor\n";
        cout << "5. Inserir um valor em uma posição\n";
        cout << "6. Remover todos os valores repetidos\n";
        cout << "7. Mostrar vetor\n";
        cout << "8. Sair\n";
        cout << "Escolha uma opção: ";
        cin >> opcao;

        switch (opcao) {
            case 1:
            {
                int valor, cont = 0;
                cout << "Informe o valor que você quer verificar a quantidade de vezes em que ele aparece: ";
                cin >> valor;
                for (int i = 0; i < tamanho; i++) {
                    if (vetor[i] == valor)
                        cont++;
                }
                cout << "O valor " << valor << " aparece " << cont << " vezes.\n";
                break;
            }

            case 2:
            {
                int inicio, fim, cont = 0, valor;
                cout << "Informe o valor a ser verificado: ";
                cin >> valor;
                cout << "Informe o início do intervalo para que os números sejam contados: ";
                cin >> inicio;
                cout << "Informe o fim do intervalo para que os números sejam contados: ";
                cin >> fim;
                for (int i = 0; i < tamanho; i++) {
                    if (i >= inicio && i <= fim && vetor[i] == valor)
                        cont++;
                }
                cout << "Existem " << cont << " valores no intervalo escolhido.\n";
                break;
            }

            case 3:
            {
                int valor, posicao = -1;
                cout << "Informe o valor que você quer procurar a sua primeira ocorrência: ";
                cin >> valor;
                for (int i = 0; i < tamanho; i++) {
                    if (vetor[i] == valor) {
                        posicao = i;
                        break;
                    }
                }
                if (posicao != -1)
                    cout << "Primeira ocorrência na posição " << posicao << ".\n";
                else
                    cout << "Valor não encontrado.\n";
                break;
            }

            case 4:
            {
                int valor, posicao = -1;
                cout << "Informe o valor que você quer que seja excluído: ";
                cin >> valor;
                for (int i = 0; i < tamanho; i++) {
                    if (vetor[i] == valor) {
                        posicao = i;
                        break;
                    }
                }
                if (posicao != -1) {
                    for (int i = posicao; i < tamanho - 1; i++) {
                        vetor[i] = vetor[i + 1];
                    }
                    tamanho--;
                    cout << "Valor excluído.\n";
                } else {
                    cout << "Valor não encontrado.\n";
                }
                break;
            }

            case 5:
            {
                if (tamanho >= 100) {
                    cout << "Vetor cheio.\n";
                    break;
                }
                int valor, posicao;
                cout << "Informe o valor que você quer inserir: ";
                cin >> valor;
                cout << "Informe a posição que você quer que o valor anterior seja inserido: ";
                cin >> posicao;
                if (posicao < 0 || posicao > tamanho) {
                    cout << "Posição inválida.\n";
                } else {
                    for (int i = tamanho; i > posicao; i--) {
                        vetor[i] = vetor[i - 1];
                    }
                    vetor[posicao] = valor;
                    tamanho++;
                    cout << "Valor inserido.\n";
                }
                break;
            }

            case 6:
            {
                for (int i = 0; i < tamanho; i++) {
                    for (int j = i + 1; j < tamanho;) {
                        if (vetor[i] == vetor[j]) {
                            for (int k = j; k < tamanho - 1; k++) {
                                vetor[k] = vetor[k + 1];
                            }
                            tamanho--;
                        } else {
                            j++;
                        }
                    }
                }
                cout << "Os valores repetidos foram removidos.\n";
                break;
            }

            case 7:
            {
                cout << "Vetor atual, após as modificações é:\n";
                for (int i = 0; i < tamanho; i++) {
                    cout << vetor[i] << " ";
                }
                cout << endl;
                break;
            }
            case 8:
                cout << "Saindo do programa\n";
                break;
            default:
                cout << "Opção inválida. Tente novamente.\n";
        }
    } while (opcao != 8);

    return 0;
}
